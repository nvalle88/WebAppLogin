﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.ObjectTransfer
{
    public class DocumentoInstitucionalTransfer
    {
        public string Nombre { get; set; }
        public byte[] Fichero { get; set; }
    }
}
