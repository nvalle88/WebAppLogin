﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
  public class Codificar
    {
        public string Entrada { get; set; }
        public string Salida { get; set; }
    }
}
