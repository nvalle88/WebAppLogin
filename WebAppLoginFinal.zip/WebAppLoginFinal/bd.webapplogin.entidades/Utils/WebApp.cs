﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Utils
{
   public static class WebApp
    {
        public static string BaseAddressSeguridad { get; set; }

        public static string NombreAplicacion { get; set; }
    }
}
