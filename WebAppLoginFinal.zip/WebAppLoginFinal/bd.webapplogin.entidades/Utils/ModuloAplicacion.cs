﻿namespace bd.webappseguridad.entidades.ModeloTransferencia
{
    public class ModuloAplicacion
    {
        public string Path { get; set; }
        public string NombreAplicacion { get; set; }

    }
}
