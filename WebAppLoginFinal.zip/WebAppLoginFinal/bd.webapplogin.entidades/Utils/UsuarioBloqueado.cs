﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webapplogin.entidades.Utils
{
  public class UsuarioBloqueado
  {
    public bool EstaBloqueado { get; set; }
  }
}
