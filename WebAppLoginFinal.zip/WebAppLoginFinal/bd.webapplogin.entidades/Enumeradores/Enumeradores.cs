﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.webappth.entidades.Enumeradores
{
    public enum Aplicacion
    {
        SwTH, webappth
    } 
}
